set(CMAKE_HOST_SYSTEM "Linux-6.17.0-1022-azure")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "6.17.0-1022-azure")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/usr/local/lib/android/sdk/ndk/27.3.13750724/build/cmake/android.toolchain.cmake")

set(CMAKE_SYSTEM "Android-1")
set(CMAKE_SYSTEM_NAME "Android")
set(CMAKE_SYSTEM_VERSION "1")
set(CMAKE_SYSTEM_PROCESSOR "aarch64")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
