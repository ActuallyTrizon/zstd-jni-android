
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/decompress/huf_decompress_amd64.S" "/home/runner/work/zstd-jni-android/zstd-jni-android/build/CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/huf_decompress_amd64.S.o"
  )
set(CMAKE_ASM_COMPILER_ID "Clang")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM
  "ZSTD_MULTITHREAD=1"
  "zstd_jni_dh_1_5_7_16_EXPORTS"
  )

# The include file search paths:
set(CMAKE_ASM_TARGET_INCLUDE_PATH
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/decompress"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/dictBuilder"
  "/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/debug.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/debug.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/debug.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/entropy_common.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/entropy_common.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/entropy_common.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/error_private.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/error_private.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/error_private.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/fse_decompress.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/fse_decompress.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/fse_decompress.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/pool.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/pool.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/pool.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/threading.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/threading.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/threading.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/xxhash.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/xxhash.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/xxhash.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/zstd_common.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/zstd_common.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/zstd_common.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/fse_compress.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/fse_compress.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/fse_compress.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/hist.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/hist.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/hist.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/huf_compress.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/huf_compress.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/huf_compress.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_compress.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_compress_literals.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_literals.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_literals.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_compress_sequences.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_sequences.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_sequences.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_compress_superblock.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_superblock.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_superblock.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_double_fast.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_double_fast.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_double_fast.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_fast.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_fast.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_fast.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_lazy.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_lazy.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_lazy.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_ldm.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_ldm.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_ldm.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_opt.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_opt.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_opt.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstd_preSplit.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_preSplit.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_preSplit.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/compress/zstdmt_compress.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstdmt_compress.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstdmt_compress.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/decompress/huf_decompress.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/huf_decompress.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/huf_decompress.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/decompress/zstd_ddict.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_ddict.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_ddict.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/decompress/zstd_decompress.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_decompress.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_decompress.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/decompress/zstd_decompress_block.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_decompress_block.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_decompress_block.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/dictBuilder/cover.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/cover.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/cover.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/dictBuilder/divsufsort.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/divsufsort.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/divsufsort.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/dictBuilder/fastcover.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/fastcover.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/fastcover.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/dictBuilder/zdict.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/zdict.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/zdict.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/jni_bufferdecompress_zstd.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_bufferdecompress_zstd.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_bufferdecompress_zstd.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/jni_directbuffercompress_zstd.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_directbuffercompress_zstd.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_directbuffercompress_zstd.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/jni_directbufferdecompress_zstd.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_directbufferdecompress_zstd.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_directbufferdecompress_zstd.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/jni_fast_zstd.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_fast_zstd.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_fast_zstd.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/jni_inputstream_zstd.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_inputstream_zstd.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_inputstream_zstd.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/jni_outputstream_zstd.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_outputstream_zstd.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_outputstream_zstd.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/jni_zdict.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_zdict.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_zdict.c.o.d"
  "/home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/jni_zstd.c" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_zstd.c.o" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_zstd.c.o.d"
  "" "libzstd-jni_dh-1.5.7-16.so" "gcc" "CMakeFiles/zstd-jni_dh-1.5.7-16.dir/link.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
