# Empty compiler generated dependencies file for zstd-jni_dh-1.5.7-16.
# This may be replaced when dependencies are built.
