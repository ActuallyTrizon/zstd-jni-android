# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for zstd-jni_dh-1.5.7-16.
