libzstd-jni_dh-1.5.7-16.so: \
 /usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/crtbegin_so.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/debug.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/entropy_common.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/error_private.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/fse_decompress.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/pool.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/threading.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/xxhash.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/zstd_common.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/fse_compress.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/hist.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/huf_compress.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_literals.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_sequences.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_superblock.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_double_fast.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_fast.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_lazy.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_ldm.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_opt.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_preSplit.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstdmt_compress.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/huf_decompress.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_ddict.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_decompress.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_decompress_block.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/cover.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/divsufsort.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/fastcover.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/zdict.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_bufferdecompress_zstd.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_directbuffercompress_zstd.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_directbufferdecompress_zstd.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_fast_zstd.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_inputstream_zstd.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_outputstream_zstd.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_zdict.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_zstd.c.o \
 CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/huf_decompress_amd64.S.o \
 /usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/lib/clang/18/lib/linux/aarch64/libatomic.a \
 /usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/libm.so \
 /usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/lib/clang/18/lib/linux/libclang_rt.builtins-aarch64-android.a \
 /usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/lib/clang/18/lib/linux/aarch64/libunwind.a \
 /usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/libdl.so \
 /usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/libc.so \
 /usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/crtend_so.o

/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/crtbegin_so.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/debug.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/entropy_common.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/error_private.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/fse_decompress.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/pool.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/threading.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/xxhash.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/zstd_common.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/fse_compress.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/hist.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/huf_compress.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_literals.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_sequences.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_compress_superblock.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_double_fast.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_fast.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_lazy.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_ldm.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_opt.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstd_preSplit.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/compress/zstdmt_compress.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/huf_decompress.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_ddict.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_decompress.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/zstd_decompress_block.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/cover.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/divsufsort.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/fastcover.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/dictBuilder/zdict.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_bufferdecompress_zstd.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_directbuffercompress_zstd.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_directbufferdecompress_zstd.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_fast_zstd.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_inputstream_zstd.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_outputstream_zstd.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_zdict.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/jni_zstd.c.o:

CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/decompress/huf_decompress_amd64.S.o:

/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/lib/clang/18/lib/linux/aarch64/libatomic.a:

/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/libm.so:

/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/lib/clang/18/lib/linux/libclang_rt.builtins-aarch64-android.a:

/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/lib/clang/18/lib/linux/aarch64/libunwind.a:

/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/libdl.so:

/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/libc.so:

/usr/local/lib/android/sdk/ndk/27.3.13750724/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/26/crtend_so.o:
