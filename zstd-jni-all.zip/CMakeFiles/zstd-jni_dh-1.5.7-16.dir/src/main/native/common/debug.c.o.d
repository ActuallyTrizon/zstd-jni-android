CMakeFiles/zstd-jni_dh-1.5.7-16.dir/src/main/native/common/debug.c.o: \
  /home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/debug.c \
  /home/runner/work/zstd-jni-android/zstd-jni-android/src/main/native/common/debug.h
